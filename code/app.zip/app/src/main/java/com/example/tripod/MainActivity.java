package com.example.tripod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import org.json.JSONException;
import org.json.JSONObject;


import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Handler handler;
    private static final int MY_PERMISSIONS_REQUEST_INTERNET = 100;

    private Runnable runnable;

    private boolean is_connected = false;
    public JetBotApiHelper jetBotApiHelper;

    private boolean is_park_command_sended = false;
    private int park_command_count_time =0;

    public EditText jetson_ip_edittext,park_number_edittext;
    public TextView jetbot_status_textView, red_line_count_textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jetbot_status_textView = findViewById(R.id.jetbot_status_textView);
        red_line_count_textView = findViewById(R.id.red_line_count_textView);

        jetson_ip_edittext = findViewById(R.id.jetson_ip_edittext);
        park_number_edittext = findViewById(R.id.park_number_edittext);

        jetBotApiHelper = JetBotApiHelper.getInstance(this);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            // İzin yoksa, kullanıcıdan izin iste
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, MY_PERMISSIONS_REQUEST_INTERNET);
        } else {
            // İzin zaten verilmişse, işleme devam et
            // Socket işlemleri burada yapılır
        }

        handler = new Handler(Looper.getMainLooper());

        // Zamanlayıcıyı başlat
        startTimer();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_PERMISSIONS_REQUEST_INTERNET) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // İzin verildi, işleme devam et
                // Socket işlemleri burada yapılır
            } else {
                // İzin reddedildi, kullanıcıya uygun geri bildirim verilebilir
            }
        }
    }

    private void startTimer() {
        runnable = new Runnable() {
            @Override
            public void run() {
                    // Her saniye getJetBotStatus fonksiyonunu çağır
                    park_command_count_time++;
                    getJetBotStatus(jetson_ip_edittext.getText().toString());
                    if(is_connected == true){
                        jetson_ip_edittext.setTextColor(Color.parseColor("#34eb3d"));
                    }else{
                        jetson_ip_edittext.setTextColor(Color.parseColor("#f5051d"));
                    }

                    if(park_command_count_time > 120){
                        is_park_command_sended = false;
                    }

                    // Zamanlayıcıyı bir sonraki saniyeye ayarla
                    handler.postDelayed(this, 1000); // 1000 milisaniye = 1 saniye


            }
        };

        // İlk çağrıyı hemen başlat
        handler.post(runnable);
    }

    private void getJetBotStatus(String jetbot_ip) {
        // JetBot status isteğini burada gönder

            jetBotApiHelper.getJetBotStatus(jetbot_ip, new JetBotApiHelper.VolleyCallback() {
                @Override
                public void onSuccess(JSONObject result) {
                    // Başarılı yanıt alındığında yapılacak işlemler
                    System.out.println("result can :" + result);
                    is_connected = true;
                    try {
                        String connectionStatus = result.getString("connection_status");
                        String jetbotStatus = result.getString("jetbot_status");
                        //String red_line_count = result.getString("red_line_count");

                        jetbot_status_textView.setText(jetbotStatus);
                        System.out.println("jetbot status can : " + jetbotStatus);
                        switch (jetbotStatus) {
                            case "waiting":
                                jetbot_status_textView.setTextColor(Color.parseColor("#f57505"));
                                break;
                            case "parked":
                                red_line_count_textView.setText("1");

                        }

                        //red_line_count_textView.setText(red_line_count);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

                @Override
                public void onError(String errorMessage) {
                    // Hata durumunda yapılacak işlemler
                    System.out.println("result hata :" + errorMessage);
                    jetbot_status_textView.setText("no connection");
                    red_line_count_textView.setText("0");
                    is_connected = false;
                }
            });

    }



    public void park_jetbot(View view){
        //for parking jetbot

        jetBotApiHelper.sendCommandToJetBot(jetson_ip_edittext.getText().toString(),Integer.parseInt(park_number_edittext.getText().toString()),new JetBotApiHelper.VolleyCallback() {
            @Override
            public void onSuccess(JSONObject result) {
                System.out.println("komut basıldı : "+result);
                is_park_command_sended =true;
            }

            @Override
            public void onError(String errorMessage) {
                System.out.println("komut basılamadı : "+errorMessage);
            }
        });
    }
}