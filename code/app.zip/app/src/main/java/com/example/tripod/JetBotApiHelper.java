package com.example.tripod;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class JetBotApiHelper {
    private static JetBotApiHelper instance;
    private RequestQueue requestQueue;
    private static Context ctx;

    private JetBotApiHelper(Context context) {
        ctx = context;
        requestQueue = getRequestQueue();
    }

    public static synchronized JetBotApiHelper getInstance(Context context) {
        if (instance == null) {
            instance = new JetBotApiHelper(context);
        }
        return instance;
    }

    private RequestQueue getRequestQueue() {
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(ctx.getApplicationContext());
        }
        return requestQueue;
    }

    public void getJetBotStatus(String jetbot_ip_address,final VolleyCallback callback) {
        String url = "http://"+jetbot_ip_address+":4646/get_jetbot_status";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(com.android.volley.VolleyError error) {
                        callback.onError(error.toString());
                    }
                });

        requestQueue.add(jsonObjectRequest);
    }

    public void sendCommandToJetBot(String jetbot_ip,int park_number, final VolleyCallback callback) {
        String url = "http://"+jetbot_ip+":4646/park";
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("park_number", park_number);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, jsonBody, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        callback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(com.android.volley.VolleyError error) {
                        callback.onError(error.toString());
                    }
                });

        requestQueue.add(jsonObjectRequest);
    }

    public interface VolleyCallback {
        void onSuccess(JSONObject result);
        void onError(String errorMessage);
    }
}
